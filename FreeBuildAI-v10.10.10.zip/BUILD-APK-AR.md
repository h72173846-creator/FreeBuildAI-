# بناء APK — FreeBuild AI v10.10.10

## بناء المشروع نفسه
- ارفع المجلد كاملًا إلى GitHub.
- افتح Actions ثم `Build FreeBuild AI APK` وشغّل workflow يدويًا.
- بعد نجاحه، نزّل Artifact `FreeBuildAI-debug-APK`.

## ملاحظات
- يتطلب البناء Java 17 وAndroid SDK وGradle، ويتم إعدادها في GitHub Actions.
- الناتج APK تجريبي (debug) وليس إصدار متجر موقّعًا.
- لم يُنفّذ بناء Android فعلي داخل بيئة التعديل هذه؛ تحقق من سجل GitHub Actions قبل اعتبار APK ناجحًا.
